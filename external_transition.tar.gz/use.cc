#include <cstdlib>
#include <iostream>

int main(int argc, char *argv[]) {
  std::cout << "use\n";
  return EXIT_SUCCESS;
}
