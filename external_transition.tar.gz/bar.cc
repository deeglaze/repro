#include <cstdlib>
#include <iostream>

int main(int argc, char *argv[]) {
  std::cout << "bar\n";
  return EXIT_SUCCESS;
}
