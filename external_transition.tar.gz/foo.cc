#include <cstdlib>
#include <iostream>

int main(int argc, char *argv[]) {
  std::cout << "foo\n";
  return EXIT_SUCCESS;
}
